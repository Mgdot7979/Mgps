# 테스트 GPS 2.2 — 수정본 v4

이 ZIP은 소스 프로젝트이며 설치용 APK가 아닙니다. 패키지명은 `com.example.mockgps`입니다.
모의 위치 앱으로 지정한 기기에서 테스트용 좌표를 제공합니다. 감지 우회 기능은 없습니다.
이번 수정본은 Android 빌드/실기기 검증 전입니다. 검증 범위는 VALIDATION.md를 읽으세요.

## 기능과 사용 방법
1. 빌드하여 설치한 다음 개발자 옵션의 ‘모의 위치 앱’에 ‘테스트 GPS’를 지정하세요.
2. 기기 위치 기능을 켜고 앱에서 위치 권한을 허용하세요.
3. 앱에서 위치 제공 방식을 선택하세요.
   - Android 플랫폼은 `gps` 및 제공되는 경우 `network` 테스트 공급자를 사용합니다.
   - Google Play 서비스는 공식 FLP `setMockMode`/`setMockLocation` API를 사용합니다.
     Google Play 서비스가 설치되어 있어야 합니다. 미지원 기기에서는 오류를 표시하며 자동 전환하지 않습니다.
   - 두 방식은 동시에 주입하지 않습니다. 다른 앱/제조사에서의 호환성은 보장하지 않습니다.
4. 고정 좌표 또는 출발지/도착지를 입력하고 시작하세요. 도로 경로는 HTTPS OSRM 자동차 경로 API로 조회합니다.
   입력 좌표를 외부 서버에 전송하기 전에 동의를 받습니다. 도로 보정점과 경로 길이를 확인한 뒤 시작합니다.
5. 속도는 0~200 km/h이며 실행 중 변경할 수 있습니다. 일시정지, 재개, 중지 및 도착 자동 중지를 지원합니다.
6. 앱을 전환해도 포그라운드 서비스가 실행됩니다. 알림에서 제어할 수 있습니다. 최대 실행 시간은 6시간입니다.

## 이번 수정
- 누락된 ForegroundServiceStartNotAllowedException import를 추가했습니다.
- Activity가 재개된 상태에서만 시작하며 위치 권한/위치 기능을 재확인합니다.
  Android 14의 while-in-use 제한은 OS가 최종 판단하므로 예외 처리도 유지합니다.
- 시작 실패 시 즉시 서비스를 중지합니다. 준비 중 중지/새 시작 요청은 이전 결과를 무효화합니다.
- 공급자별 성공과 오류를 구분합니다. 모든 주입 실패/권한 회수 시 중지하며 일부 실패는 제한 동작으로 표시합니다.
- 공급자 추가 직후 소유권을 기록합니다. 활성화 실패를 롤백하고 비활성화 실패와 무관하게 제거를 시도합니다.
- 경로 저장/로딩/전처리, 위치 API 작업, 정리는 UI 스레드가 아닌 직렬 작업 스레드에서 실행합니다.
- FLP 작업 완료를 작업 스레드에서 최대 5초 기다립니다. 타임아웃/실패는 정상 성공으로 표시하지 않습니다.
  종료 시 모의 모드 해제를 시도하고 실패하면 기록 및 복구 안내를 제공합니다.
- 임의의 고도 45m와 정밀도 메타데이터를 제거했습니다. 수평 정확도 5m는 명시적 테스트 값이며 측정값이 아닙니다.
- 기존 15개 이동 엔진 테스트에 10개 공급자 회귀 테스트를 추가했습니다. 작성만 했으며 이 환경에서는 실행하지 않았습니다.

## 빌드
JDK 17, Android SDK 35, Gradle 8.9가 필요합니다. AGP 8.7.3 / Kotlin 2.0.21을 사용합니다.
Google Play 서비스 위치 라이브러리 21.3.0 의존성이 추가되어 최초 빌드에 인터넷이 필요합니다.
Android SDK 경로는 ANDROID_HOME 또는 local.properties의 sdk.dir에 설정하세요.

이 ZIP에는 Gradle Wrapper JAR/스크립트가 없습니다. 시스템에 Gradle 8.9를 설치한 뒤 프로젝트 루트에서 실행하세요.

```sh
gradle --version
gradle testDebugUnitTest assembleDebug lintDebug
```

Wrapper가 필요하면 설치한 Gradle로 먼저 `gradle wrapper --gradle-version 8.9`를 실행하세요.
그 뒤에만 `./gradlew`(Windows: `gradlew.bat`)를 사용할 수 있습니다.
Android Studio에서는 로컬 Gradle 배포본 8.9를 지정하거나 위 절차로 Wrapper를 생성한 뒤 Sync하세요.
디버그 APK 경로는 `app/build/outputs/apk/debug/app-debug.apk`입니다.
동일 서명키로 빌드하면 기존 앱을 업데이트할 수 있습니다. 서명키가 다르면 기존 앱을 제거해야 합니다.

GitHub에 프로젝트 루트 내용을 올리면 `.github/workflows/android.yml`로 빌드와 테스트를 요청할 수 있습니다.
워크플로 파일만 제공했으며 여기서 실행하지 않았습니다.

## 제한과 주의
- 위치는 여전히 모의 위치로 표시됩니다. FLP 지원은 감지 우회가 아닙니다.
- Google Play 서비스 FLP 모의 모드는 다른 FLP 클라이언트에도 영향을 줄 수 있으므로 테스트 기기를 권장합니다.
- 앱 강제 종료/프로세스 사망에서는 정리 콜백 실행을 보장할 수 없습니다. 정리 실패 후 위치가 복구되지 않으면
  모의 위치 앱 설정을 확인하고 기기를 재시작하세요. 중지는 API 대기 중 최대 수 초 늦어질 수 있습니다.
- 500ms는 다음 주입 예약 간격입니다. FLP 완료 시간과 OS 스케줄링 때문에 실제 간격은 더 길어질 수 있습니다.
- 재개된 화면에서만 시작하더라도 OS 상태가 바뀌면 시작이 거부될 수 있습니다. 화면에서 다시 시작하세요.
- 알림 권한 거부가 곧 서비스 종료를 의미하지는 않습니다. 알림 서랍 제어가 제한될 수 있습니다.
- 회전 시 입력값은 보존하지만 경로 조회/저장 준비는 취소하며 자동 재개하지 않습니다.
- 취소 후 남은 앱 내부 경로 파일은 다음 저장 시 24시간 경과 파일 정리 대상으로 처리합니다.
- OSRM 공개 서버의 가용성, 교통/제한속도 및 모든 도로 데이터의 정확성은 보장하지 않습니다.
- 플랫폼 경로와 FLP 경로 모두 실기기별 검증이 필요합니다. 실제 운전/내비게이션용 앱이 아닙니다.

## 근거 문서
- https://developers.google.com/android/reference/com/google/android/gms/location/FusedLocationProviderClient
- https://developer.android.com/about/versions/14/changes/fgs-types-required
- https://developer.android.com/reference/android/location/LocationManager
- https://project-osrm.org/docs/v5.24.0/#route-service
도로 데이터: © OpenStreetMap contributors — https://www.openstreetmap.org/copyright
