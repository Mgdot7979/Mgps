package com.example.mockgps

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URI
import java.util.UUID
import javax.net.ssl.HttpsURLConnection

object RouteRepository {
    const val DEFAULT_SERVER = "https://router.project-osrm.org"
    private const val MAX_BYTES = 8 * 1024 * 1024
    data class Result(val route: RouteTrack, val reportedMeters: Double)

    fun endpoint(text: String): URI {
        val uri = URI(text.trim().trimEnd('/'))
        require(uri.scheme.equals("https", true) && !uri.host.isNullOrBlank() &&
            uri.rawUserInfo == null && uri.rawQuery == null && uri.rawFragment == null) {
            "서버 주소는 사용자 정보·쿼리·프래그먼트가 없는 HTTPS 주소여야 합니다."
        }
        return uri
    }

    /** Only the two user-entered coordinates are submitted. No device location is read. */
    fun fetch(server: String, start: GeoPoint, end: GeoPoint): Result {
        val base = endpoint(server).toASCIIString().trimEnd('/')
        val url = URI("$base/route/v1/driving/${start.longitude},${start.latitude};${end.longitude},${end.latitude}" +
            "?overview=full&geometries=geojson&steps=false&alternatives=false").toURL()
        val connection = url.openConnection() as HttpsURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 20000
        connection.instanceFollowRedirects = false
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "MockGpsRoute-Android/2.0")
        try {
            require(connection.responseCode == 200) { "경로 서버 HTTP ${connection.responseCode}: 서버와 좌표를 확인하세요." }
            require(connection.contentLengthLong <= MAX_BYTES) { "경로 응답이 너무 큽니다. 더 짧은 구간을 선택하세요." }
            val out = ByteArrayOutputStream()
            connection.inputStream.use { stream ->
                val buffer = ByteArray(8192)
                while (true) {
                    if (Thread.currentThread().isInterrupted) throw InterruptedException("조회가 취소되었습니다.")
                    val count = stream.read(buffer)
                    if (count == -1) break
                    require(out.size() + count <= MAX_BYTES) { "경로 응답은 8MB 이하여야 합니다." }
                    out.write(buffer, 0, count)
                }
            }
            val json = JSONObject(out.toString("UTF-8"))
            require(json.optString("code") == "Ok") { "도로 경로를 찾지 못했습니다: ${json.optString("code")}" }
            val routes = json.getJSONArray("routes")
            require(routes.length() > 0) { "조회된 경로가 없습니다." }
            val first = routes.getJSONObject(0)
            val geometry = first.getJSONObject("geometry")
            require(geometry.getString("type") == "LineString") { "지원하지 않는 경로 형식입니다." }
            val route = decodePoints(geometry.getJSONArray("coordinates"))
            require(!route.fixed && route.totalMeters > 1.0) { "출발지와 도착지를 서로 다른 도로 지점으로 지정하세요." }
            val reported = first.getDouble("distance")
            require(reported.isFinite() && reported >= 0.0)
            return Result(route, reported)
        } finally {
            connection.disconnect()
        }
    }
    private fun decodePoints(array: JSONArray): RouteTrack {
        require(array.length() in 1..50000) { "경로의 점 개수가 허용 범위를 벗어났습니다." }
        return RouteTrack((0 until array.length()).map { i ->
            val pair = array.getJSONArray(i)
            GeoPoint(pair.getDouble(1), pair.getDouble(0)) // GeoJSON = longitude, latitude.
        })
    }
    fun delete(context: Context, name: String) {
        require(Regex("[a-f0-9-]{36}[.]json").matches(name))
        File(File(context.filesDir, "routes"), name).delete()
    }
    fun save(context: Context, route: RouteTrack): String {
        val folder = File(context.filesDir, "routes").apply { check(isDirectory || mkdirs()) }
        folder.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 86400000L }?.forEach { it.delete() }
        val name = UUID.randomUUID().toString() + ".json"
        val temp = File(folder, "$name.tmp")
        try {
            val points = JSONArray()
            route.points.forEach {
                if (Thread.currentThread().isInterrupted) throw InterruptedException("경로 저장이 취소되었습니다.")
                points.put(JSONArray().put(it.longitude).put(it.latitude))
            }
            val bytes = points.toString().toByteArray(Charsets.UTF_8)
            require(bytes.size <= MAX_BYTES) { "저장 경로가 너무 큽니다." }
            temp.writeBytes(bytes)
            if (Thread.currentThread().isInterrupted) throw InterruptedException("경로 저장이 취소되었습니다.")
            check(temp.renameTo(File(folder, name))) { "경로 파일을 저장하지 못했습니다." }
            return name
        } finally { temp.delete() }
    }
    fun loadAndDelete(context: Context, name: String): RouteTrack {
        require(Regex("[a-f0-9-]{36}[.]json").matches(name)) { "잘못된 경로 파일 이름입니다." }
        val file = File(File(context.filesDir, "routes"), name)
        require(file.exists() && file.length() in 1..MAX_BYTES.toLong()) { "경로 파일을 읽을 수 없습니다." }
        return try { decodePoints(JSONArray(file.readText())) } finally { file.delete() }
    }
}
