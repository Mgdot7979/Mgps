package com.example.mockgps

import android.Manifest
import android.app.ForegroundServiceStartNotAllowedException
import android.location.LocationManager
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.WindowInsets
import android.widget.*
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.Future

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var request: Future<*>? = null
    private var busy = false
    private var resumed = false
    private var pendingReady = false
    private var preparationGeneration = 0L
    private lateinit var backendChoice: Spinner
    private var lastFetchMs = -10000L
    private var pending: Intent? = null
    private lateinit var startLat: EditText
    private lateinit var startLon: EditText
    private lateinit var endLat: EditText
    private lateinit var endLon: EditText
    private lateinit var server: EditText
    private lateinit var speedInput: EditText
    private lateinit var speedSlider: SeekBar
    private lateinit var speedLabel: TextView
    private lateinit var consent: CheckBox
    private lateinit var note: TextView
    private lateinit var live: TextView
    private lateinit var routeButton: Button
    private lateinit var pauseButton: Button
    private lateinit var fixedButton: Button
    private var selectedSpeed = 30.0
    private val poll = object : Runnable {
        override fun run() {
            val state = SessionState.snapshot
            live.text = state.message
            pauseButton.text = if (state.paused) "이동 재개" else "일시정지"
            pauseButton.isEnabled = state.active
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getPreferences(MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (16 * resources.displayMetrics.density).toInt()
            setPadding(p, p, p, p)
        }
        fun label(text: String, size: Float = 15f): TextView = TextView(this).apply {
            this.text = text
            textSize = size
            setPadding(0, 10, 0, 10)
            layout.addView(this, LinearLayout.LayoutParams(-1, -2))
        }
        fun field(title: String, key: String, default: String, numeric: Boolean = true): EditText {
            label(title)
            return EditText(this).apply {
                setSingleLine(true)
                inputType = if (numeric) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
                    else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                setText(savedInstanceState?.getString(key) ?: prefs.getString(key, default))
                contentDescription = title
                layout.addView(this, LinearLayout.LayoutParams(-1, -2))
            }
        }
        fun button(text: String, action: () -> Unit): Button = Button(this).apply {
            this.text = text
            setOnClickListener { action() }
            layout.addView(this, LinearLayout.LayoutParams(-1, -2))
        }
        label("테스트 GPS · 도로 이동", 23f)
        label("Android 모의 위치 API를 사용합니다. 감지 우회는 지원하지 않습니다. 출발지와 도착지는 위도·경도로 입력합니다.")
        button("개발자 옵션 열기") {
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        label("개발자 옵션 → 모의 위치 앱 선택에서 ‘테스트 GPS’를 지정하고 휴대폰의 위치 기능을 켜세요.")
        label("위치 제공 방식을 선택하세요. 두 방식은 동시에 사용하지 않습니다. 타사 앱 호환성을 보장하지 않습니다.")
        backendChoice = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Android 플랫폼 (GPS / Network)", "Google Play 서비스 (FLP)"))
            setSelection(prefs.getInt("backend", 0).coerceIn(0, 1))
            layout.addView(this, LinearLayout.LayoutParams(-1, -2))
        }
        startLat = field("출발지 위도 / 고정 위도", "startLat", "37.5665")
        startLon = field("출발지 경도 / 고정 경도", "startLon", "126.9780")
        endLat = field("도착지 위도", "endLat", "37.5563")
        endLon = field("도착지 경도", "endLon", "126.9723")
        label("속도를 변경하면 실제 좌표의 이동 속도에도 반영됩니다. 0 km/h에서는 현재 위치를 유지합니다.")
        speedInput = field("이동 속도 (0~200 km/h)", "speed", "30")
        selectedSpeed = speedInput.text.toString().toDoubleOrNull()?.takeIf { it.isFinite() && it in 0.0..200.0 } ?: 30.0
        speedLabel = label("")
        speedSlider = SeekBar(this).apply {
            max = 200
            progress = selectedSpeed.toInt()
            contentDescription = "이동 속도 슬라이더"
            layout.addView(this, LinearLayout.LayoutParams(-1, -2))
        }
        updateSpeedLabel()
        speedSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    selectedSpeed = progress.toDouble()
                    speedInput.setText(progress.toString())
                    updateSpeedLabel()
                    sendSpeed()
                }
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        button("입력한 속도 적용") { readSpeed()?.let { sendSpeed(); note.text = "속도를 적용했습니다." } }
        server = field("OSRM 자동차 경로 서버 (HTTPS)", "server", RouteRepository.DEFAULT_SERVER, false)
        label("자동차용 도로 경로를 조회합니다. 공개 서버는 테스트용이며 가용성·도로 정확성을 보장하지 않습니다. 보행/자전거 경로, 교통 상황, 제한 속도는 반영하지 않습니다.")
        consent = CheckBox(this).apply {
            text = "입력한 출발지·도착지 좌표를 위 경로 서버로 전송하는 데 동의합니다."
            // Deliberately unchecked each time this activity is created.
            layout.addView(this, LinearLayout.LayoutParams(-1, -2))
        }
        note = label("경로를 조회하면 도로에 맞춰 보정된 시작점과 끝점을 먼저 확인할 수 있습니다.")
        fixedButton = button("출발지 좌표에 고정 / 시작") {
            try {
                val point = readPoint(startLat, startLon)
                val speed = readSpeed() ?: return@button
                prepareStart(Intent(this, MockLocationService::class.java).setAction(MockLocationService.START)
                    .putExtra("lat", point.latitude).putExtra("lon", point.longitude).putExtra("speed", speed))
            } catch (e: Exception) { note.text = e.message }
        }
        routeButton = button("도로 경로 조회 / 이동 준비") { fetchRoute() }
        pauseButton = button("일시정지") { command(MockLocationService.PAUSE) }
        button("중지") {
            preparationGeneration++
            request?.cancel(true)
            setFetchFinished()
            pending = null
            pendingReady = false
            command(MockLocationService.STOP)
            note.text = "준비/실행 중인 작업의 중지를 요청했습니다."
        }
        live = label(SessionState.snapshot.message)
        label("다른 앱을 열어도 서비스는 계속 실행하도록 구성했습니다. 알림의 ‘중지’로 종료할 수 있습니다. 제조사의 절전 정책에 따라 중단될 수 있으며, 한 번의 실행은 최대 6시간입니다.")
        label("도로 데이터: © OpenStreetMap contributors. 경로 엔진: OSRM. 실제 차량 운전이나 내비게이션용 앱이 아닙니다.")
        button("OpenStreetMap 저작권 안내") {
            try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.openstreetmap.org/copyright"))) }
            catch (_: Exception) { note.text = "https://www.openstreetmap.org/copyright 에서 확인하세요." }
        }
        val scroll = ScrollView(this).apply { addView(layout); fitsSystemWindows = true }
        if (Build.VERSION.SDK_INT >= 30) {
            scroll.setOnApplyWindowInsetsListener { view, insets ->
                val system = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                val ime = insets.getInsets(WindowInsets.Type.ime())
                view.setPadding(system.left, system.top, system.right, maxOf(system.bottom, ime.bottom))
                insets
            }
        }
        setContentView(scroll)
    }

    private fun readPoint(lat: EditText, lon: EditText): GeoPoint {
        val a = lat.text.toString().trim().toDoubleOrNull()
        val b = lon.text.toString().trim().toDoubleOrNull()
        require(a != null && b != null) { "위도·경도를 숫자로 입력하세요." }
        return GeoPoint(a, b)
    }
    private fun readSpeed(): Double? {
        return try {
            selectedSpeed = MotionEngine.checkedSpeed(speedInput.text.toString().trim().toDouble())
            speedSlider.progress = selectedSpeed.toInt()
            updateSpeedLabel()
            selectedSpeed
        } catch (_: Exception) {
            note.text = "속도를 0~200 km/h 사이 숫자로 입력하세요."
            null
        }
    }
    private fun updateSpeedLabel() {
        speedLabel.text = String.format(Locale.KOREA, "설정 속도는 %.1f km/h입니다.", selectedSpeed)
    }
    private fun command(action: String) {
        if (action != MockLocationService.STOP && !SessionState.snapshot.active) return
        try { startService(Intent(this, MockLocationService::class.java).setAction(action)) }
        catch (e: Exception) { note.text = "명령을 전달하지 못했습니다: ${e.message}" }
    }
    private fun sendSpeed() {
        if (!SessionState.snapshot.active) return
        try {
            startService(Intent(this, MockLocationService::class.java).setAction(MockLocationService.SPEED).putExtra("speed", selectedSpeed))
        } catch (e: Exception) { note.text = "속도를 적용하지 못했습니다: ${e.message}" }
    }
    private fun fetchRoute() {
        if (busy) return
        try {
            require(consent.isChecked) { "경로 서버로 좌표를 전송하는 데 먼저 동의해 주세요." }
            val a = readPoint(startLat, startLon)
            val b = readPoint(endLat, endLon)
            readSpeed() ?: return
            val endpoint = RouteRepository.endpoint(server.text.toString()).toASCIIString()
            require(SystemClock.elapsedRealtime() - lastFetchMs >= 2000) { "잠시 후 다시 조회하세요." }
            // Show the exact recipient each time, including after editing the server field.
            AlertDialog.Builder(this)
                .setTitle("경로 서버로 좌표를 전송할까요?")
                .setMessage("서버: $endpoint\n출발지: ${a.latitude}, ${a.longitude}\n도착지: ${b.latitude}, ${b.longitude}\n\n단말기의 실제 위치는 읽거나 전송하지 않습니다.")
                .setNegativeButton("취소", null)
                .setPositiveButton("전송 및 조회") { _, _ -> requestRoute(endpoint, a, b) }
                .show()
        } catch (e: Exception) { note.text = e.message }
    }
    private fun requestRoute(endpoint: String, a: GeoPoint, b: GeoPoint) {
        if (busy) return
        busy = true
        lastFetchMs = SystemClock.elapsedRealtime()
        routeButton.isEnabled = false
        fixedButton.isEnabled = false
        note.text = "도로 경로를 조회하고 있습니다. 기존 이동이 있다면 계속 실행됩니다."
        val requestToken = ++preparationGeneration
        request = executor.submit {
            try {
                val result = RouteRepository.fetch(endpoint, a, b)
                runOnUiThread {
                    if (isDestroyed || isFinishing || requestToken != preparationGeneration) return@runOnUiThread
                    setFetchFinished()
                    val route = result.route
                    val first = route.points.first()
                    val last = route.points.last()
                    val description = String.format(Locale.KOREA,
                        "경로 길이: %.2f km (시뮬레이션 기준)\n서버 보고 거리: %.2f km\n도로 위 시작점: %.6f, %.6f\n도로 위 도착점: %.6f, %.6f\n입력 위치에서 보정된 거리: 출발 %.0f m / 도착 %.0f m\n\n입력 좌표가 아닌 도로 위 보정점에서 시작하고 끝납니다. 현재 입력 속도로 이동하며, 기존 세션이 있으면 교체합니다.",
                        route.totalMeters / 1000, result.reportedMeters / 1000,
                        first.latitude, first.longitude, last.latitude, last.longitude,
                        GeoMath.distance(a, first), GeoMath.distance(b, last))
                    note.text = description
                    AlertDialog.Builder(this).setTitle("조회된 자동차 도로 경로")
                        .setMessage(description)
                        .setNegativeButton("취소", null)
                        .setPositiveButton("이 경로로 시작") { _, _ ->
                            val speed = readSpeed()
                            if (speed != null) {
                                if (requestToken == preparationGeneration) saveAndStart(route, speed)
                            }
                        }.show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (!isDestroyed && !isFinishing && requestToken == preparationGeneration) {
                        setFetchFinished()
                        note.text = "경로 조회에 실패했습니다: ${e.message}\n인터넷·서버·좌표를 확인하세요. 자동 재시도는 하지 않습니다."
                    }
                }
            }
        }
    }
    private fun saveAndStart(route: RouteTrack, speed: Double) {
        val saveToken = ++preparationGeneration
        val backend = if (backendChoice.selectedItemPosition == 1) "google" else "platform"
        busy = true
        routeButton.isEnabled = false
        fixedButton.isEnabled = false
        note.text = "경로 파일을 준비하고 있습니다."
        val app = applicationContext
        request = executor.submit {
            try {
                val file = RouteRepository.save(app, route)
                if (Thread.currentThread().isInterrupted) {
                    RouteRepository.delete(app, file)
                    return@submit
                }
                runOnUiThread {
                    if (isDestroyed || isFinishing || saveToken != preparationGeneration) {
                        // Safe orphan file; normal housekeeping removes it after 24 hours.
                        return@runOnUiThread
                    }
                    setFetchFinished()
                    prepareStart(Intent(this, MockLocationService::class.java).setAction(MockLocationService.START)
                        .putExtra("route", file).putExtra("speed", speed).putExtra("backend", backend))
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (!isDestroyed && !isFinishing && saveToken == preparationGeneration) {
                        setFetchFinished()
                        note.text = "경로를 준비하지 못했습니다: ${e.message}"
                    }
                }
            }
        }
    }
    private fun setFetchFinished() {
        busy = false
        routeButton.isEnabled = true
        fixedButton.isEnabled = true
    }
    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun prepareStart(intent: Intent) {
        if (!intent.hasExtra("backend")) intent.putExtra("backend", if (backendChoice.selectedItemPosition == 1) "google" else "platform")
        pending = intent
        pendingReady = false
        if (!hasLocationPermission()) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 10)
        } else requestNotificationOrStart()
    }
    private fun requestNotificationOrStart() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !getPreferences(MODE_PRIVATE).getBoolean("notificationAsked", false)) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("notificationAsked", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        } else { pendingReady = true; startPending() }
    }
    private fun startPending() {
        if (!resumed || !pendingReady || isFinishing || isDestroyed) return
        val intent = pending ?: return
        pending = null
        pendingReady = false
        try {
            if (!hasLocationPermission()) throw SecurityException("위치 권한을 허용하세요.")
            val manager = getSystemService(LocationManager::class.java)
            val enabled = if (Build.VERSION.SDK_INT >= 28) manager.isLocationEnabled else
                manager.isProviderEnabled(LocationManager.GPS_PROVIDER) || manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
            check(enabled) { "휴대폰의 위치 기능을 켜세요." }
            startForegroundService(intent)
            note.text = "모의 위치 서비스를 시작합니다. 실행 상태를 아래에서 확인하세요."
        } catch (e: Exception) {
            val isStartNotAllowed = Build.VERSION.SDK_INT >= 31 && e is ForegroundServiceStartNotAllowedException
            if (e is SecurityException) {
                note.text = "서비스 권한 오류입니다. 위치 권한을 확인하고 화면에서 다시 시작하세요: ${e.message}"
            } else if (isStartNotAllowed) {
                note.text = "서비스 시작 실패: 안드로이드 보안 정책에 따라 앱이 화면에 활성화된 상태에서만 시작할 수 있습니다."
            } else {
                note.text = "서비스 시작 실패: ${e.message}"
            }
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) {
            if (hasLocationPermission()) requestNotificationOrStart()
            else { pending = null; note.text = "포그라운드 서비스 실행을 위해 위치 권한이 필요합니다. 앱 설정에서 허용하세요." }
        }
        if (requestCode == 11) { pendingReady = true; startPending() }
    }
    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(poll)
        handler.post(poll)
    }
    override fun onPostResume() {
        super.onPostResume()
        resumed = true
        startPending()
    }
    override fun onPause() {
        resumed = false
        handler.removeCallbacks(poll)
        if (::startLat.isInitialized) {
            getPreferences(MODE_PRIVATE).edit()
                .putString("startLat", startLat.text.toString()).putString("startLon", startLon.text.toString())
                .putString("endLat", endLat.text.toString()).putString("endLon", endLon.text.toString())
                .putString("server", server.text.toString()).putString("speed", speedInput.text.toString())
                .putInt("backend", backendChoice.selectedItemPosition).apply()
        }
        super.onPause() // Deliberately does not stop the service.
    }
    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("startLat", startLat.text.toString())
        outState.putString("startLon", startLon.text.toString())
        outState.putString("endLat", endLat.text.toString())
        outState.putString("endLon", endLon.text.toString())
        outState.putString("server", server.text.toString())
        outState.putString("speed", speedInput.text.toString())
        super.onSaveInstanceState(outState)
    }
    override fun onDestroy() {
        preparationGeneration++
        pending = null
        handler.removeCallbacksAndMessages(null)
        request?.cancel(true)
        executor.shutdownNow()
        super.onDestroy()
    }
}
