package com.example.mockgps

import android.content.Context
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.location.provider.ProviderProperties
import android.os.Build
import android.util.Log
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.Tasks
import java.util.concurrent.TimeUnit

/** All methods run on the service worker, never on the UI thread. No hidden/mock-flag bypass. */
interface LocationBackend {
    fun open()
    fun send(location: Location): DeliveryReport
    fun close(): List<String>
}
class PlatformBackend(private val manager: LocationManager) : LocationBackend {
    private val registry = ManagedProviders(object : ProviderOps<Location> {
        @Suppress("DEPRECATION")
        override fun add(name: String) {
            if (Build.VERSION.SDK_INT >= 31) {
                manager.addTestProvider(name, ProviderProperties.Builder()
                    .setPowerUsage(ProviderProperties.POWER_USAGE_LOW)
                    .setAccuracy(ProviderProperties.ACCURACY_FINE)
                    .setSupportsAltitude(false).setSupportsSpeed(true).setSupportsBearing(true).build())
            } else manager.addTestProvider(name, false, false, false, false,
                false, true, true, Criteria.POWER_LOW, Criteria.ACCURACY_FINE)
        }
        override fun enable(name: String) = manager.setTestProviderEnabled(name, true)
        override fun disable(name: String) = manager.setTestProviderEnabled(name, false)
        override fun remove(name: String) = manager.removeTestProvider(name)
        override fun send(name: String, value: Location) {
            manager.setTestProviderLocation(name, Location(value).apply { provider = name })
        }
    })
    override fun open() {
        val names = mutableListOf(LocationManager.GPS_PROVIDER)
        if (LocationManager.NETWORK_PROVIDER in manager.allProviders) names.add(LocationManager.NETWORK_PROVIDER)
        // Platform "fused" is NOT the Google Play services FLP API.
        registry.install(names)
    }
    override fun send(location: Location) = registry.send(location)
    override fun close() = registry.close()
}
class GoogleFusedBackend(private val context: Context) : LocationBackend {
    private val client = LocationServices.getFusedLocationProviderClient(context)
    private var modeRequested = false
    override fun open() {
        val status = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context)
        check(status == ConnectionResult.SUCCESS) { "Google Play 서비스가 없거나 업데이트가 필요합니다(코드 $status). 플랫폼 방식을 선택하세요." }
        modeRequested = true // Also disable after a failed/timed-out enable attempt.
        Tasks.await(client.setMockMode(true), 5, TimeUnit.SECONDS)
    }
    override fun send(location: Location): DeliveryReport {
        Tasks.await(client.setMockLocation(Location(location).apply { provider = "fused" }), 5, TimeUnit.SECONDS)
        return DeliveryReport(listOf("Google FLP"), emptyList())
    }
    override fun close(): List<String> {
        if (!modeRequested) return emptyList()
        return try {
            Tasks.await(client.setMockMode(false), 5, TimeUnit.SECONDS)
            modeRequested = false
            emptyList()
        } catch (e: Exception) {
            Log.w("MockGps", "FLP cleanup failed", e)
            listOf("Google FLP 모의 모드 해제를 확인하지 못했습니다: ${e.cause?.message ?: e.message}")
        }
    }
}
