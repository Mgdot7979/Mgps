package com.example.mockgps

import kotlin.math.*

data class GeoPoint(val latitude: Double, val longitude: Double) {
    init {
        require(latitude.isFinite() && latitude in -90.0..90.0) { "위도 범위가 올바르지 않습니다." }
        require(longitude.isFinite() && longitude in -180.0..180.0) { "경도 범위가 올바르지 않습니다." }
    }
}

data class RoutePosition(val point: GeoPoint, val bearing: Float)

object GeoMath {
    private const val R = 6371008.8
    fun distance(a: GeoPoint, b: GeoPoint): Double {
        val p1 = Math.toRadians(a.latitude)
        val p2 = Math.toRadians(b.latitude)
        val dp = p2 - p1
        val dl = Math.toRadians(b.longitude - a.longitude)
        val h = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * R * asin(sqrt(h.coerceIn(0.0, 1.0)))
    }
    fun bearing(a: GeoPoint, b: GeoPoint): Float {
        val p1 = Math.toRadians(a.latitude)
        val p2 = Math.toRadians(b.latitude)
        val dl = Math.toRadians(b.longitude - a.longitude)
        return ((Math.toDegrees(atan2(sin(dl) * cos(p2),
            cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl))) + 360) % 360).toFloat()
    }
    fun interpolate(a: GeoPoint, b: GeoPoint, fraction: Double): GeoPoint {
        val t = fraction.coerceIn(0.0, 1.0)
        if (t == 0.0) return a
        if (t == 1.0) return b
        val p1 = Math.toRadians(a.latitude)
        val p2 = Math.toRadians(b.latitude)
        val l1 = Math.toRadians(a.longitude)
        val l2 = Math.toRadians(b.longitude)
        val angle = distance(a, b) / R
        if (angle < 1e-10) return a
        require(PI - angle > 1e-6) { "서로 정반대인 두 점은 도로 구간으로 사용할 수 없습니다." }
        val w1 = sin((1 - t) * angle) / sin(angle)
        val w2 = sin(t * angle) / sin(angle)
        val x = w1 * cos(p1) * cos(l1) + w2 * cos(p2) * cos(l2)
        val y = w1 * cos(p1) * sin(l1) + w2 * cos(p2) * sin(l2)
        val z = w1 * sin(p1) + w2 * sin(p2)
        return GeoPoint(Math.toDegrees(atan2(z, hypot(x, y))), Math.toDegrees(atan2(y, x)))
    }
}

class RouteTrack(raw: List<GeoPoint>) {
    val points: List<GeoPoint>
    val cumulative: DoubleArray
    val totalMeters: Double
    val fixed: Boolean get() = points.size == 1
    init {
        require(raw.isNotEmpty() && raw.size <= 50000) { "경로는 1~50,000개의 점이어야 합니다." }
        val clean = ArrayList<GeoPoint>()
        for (point in raw) {
            if (clean.isEmpty() || GeoMath.distance(clean.last(), point) > 0.01) clean.add(point)
        }
        points = clean.toList()
        cumulative = DoubleArray(points.size)
        for (i in 1 until points.size) {
            cumulative[i] = cumulative[i - 1] + GeoMath.distance(points[i - 1], points[i])
        }
        totalMeters = cumulative.last()
    }
    fun position(meters: Double): RoutePosition {
        require(meters.isFinite())
        if (fixed) return RoutePosition(points[0], 0f)
        val d = meters.coerceIn(0.0, totalMeters)
        if (d >= totalMeters) return RoutePosition(points.last(), GeoMath.bearing(points[points.lastIndex - 1], points.last()))
        // Upper bound: a vertex belongs to the segment starting at that vertex.
        var lo = 1
        var hi = cumulative.lastIndex
        while (lo < hi) {
            val mid = (lo + hi) / 2
            if (cumulative[mid] <= d) lo = mid + 1 else hi = mid
        }
        val i = lo
        val fraction = (d - cumulative[i - 1]) / (cumulative[i] - cumulative[i - 1])
        val point = GeoMath.interpolate(points[i - 1], points[i], fraction)
        return RoutePosition(point, GeoMath.bearing(point, points[i]))
    }
}

/** Monotonic elapsed-time movement. Speed changes apply only to future elapsed time. */
class MotionEngine(val route: RouteTrack, initialKmh: Double, startMs: Long) {
    var speedKmh: Double = checkedSpeed(initialKmh)
        private set
    var traveled: Double = 0.0
        private set
    var paused: Boolean = false
        private set
    private var lastMs = startMs
    val finished: Boolean get() = !route.fixed && traveled >= route.totalMeters
    val effectiveMps: Double get() = if (paused || finished || route.fixed) 0.0 else speedKmh / 3.6
    fun advance(nowMs: Long) {
        require(nowMs >= lastMs) { "단조 증가 시계가 필요합니다." }
        val seconds = (nowMs - lastMs) / 1000.0
        traveled = (traveled + effectiveMps * seconds).coerceAtMost(route.totalMeters)
        lastMs = nowMs
    }
    fun changeSpeed(kmh: Double, nowMs: Long) {
        val checked = checkedSpeed(kmh)
        advance(nowMs)
        speedKmh = checked
    }
    fun setPaused(value: Boolean, nowMs: Long) {
        advance(nowMs)
        paused = value
    }
    companion object {
        fun checkedSpeed(kmh: Double): Double {
            require(kmh.isFinite() && kmh in 0.0..200.0) { "속도는 0~200 km/h여야 합니다." }
            return kmh
        }
    }
}
