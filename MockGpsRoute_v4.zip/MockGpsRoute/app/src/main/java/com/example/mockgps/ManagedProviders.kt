package com.example.mockgps

/** Android-independent ownership logic, also used by regression tests. */
interface ProviderOps<T> {
    fun add(name: String)
    fun enable(name: String)
    fun disable(name: String)
    fun remove(name: String)
    fun send(name: String, value: T)
}
data class DeliveryReport(val succeeded: List<String>, val errors: List<String>)
class ManagedProviders<T>(private val ops: ProviderOps<T>) {
    private val owned = linkedSetOf<String>()
    private val active = linkedSetOf<String>()
    val setupWarnings = mutableListOf<String>()
    fun install(names: List<String>) {
        for (name in names.distinct()) {
            try {
                ops.add(name)
                owned.add(name) // Record ownership BEFORE enabling, so rollback cannot lose it.
                ops.enable(name)
                active.add(name)
            } catch (e: Exception) {
                setupWarnings.add("$name 등록 실패: ${e.message}")
                if (name in owned) removeOne(name)
                if (e is SecurityException) throw e
            }
        }
        check(active.isNotEmpty()) { "모든 공급자 등록에 실패했습니다. ${setupWarnings.joinToString()}" }
    }
    fun send(value: T): DeliveryReport {
        val successes = mutableListOf<String>()
        val errors = mutableListOf<String>()
        for (name in active) {
            try { ops.send(name, value); successes.add(name) }
            catch (e: SecurityException) { throw e }
            catch (e: Exception) { errors.add("$name: ${e.message}") }
        }
        check(successes.isNotEmpty()) { "모든 공급자의 위치 주입에 실패했습니다. ${errors.joinToString()}" }
        return DeliveryReport(successes, setupWarnings + errors)
    }
    private fun removeOne(name: String): String? {
        active.remove(name)
        try { ops.disable(name) } catch (_: Exception) { /* Removal MUST still be attempted. */ }
        return try {
            ops.remove(name)
            owned.remove(name)
            null
        } catch (e: Exception) { "$name 제거 실패: ${e.message}" }
    }
    fun close(): List<String> = owned.toList().mapNotNull { removeOne(it) }
}
