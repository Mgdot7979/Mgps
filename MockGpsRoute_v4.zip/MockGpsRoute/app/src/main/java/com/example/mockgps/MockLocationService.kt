package com.example.mockgps

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationManager
import android.os.*
import android.util.Log
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

class MockLocationService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val thread = HandlerThread("MockGps-worker")
    private lateinit var worker: Handler
    private lateinit var manager: LocationManager
    private val generation = AtomicLong()
    @Volatile private var destroyed = false
    private var token = 0L
    private var commandId = 0
    private var backend: LocationBackend? = null
    private var engine: MotionEngine? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var startedMs = 0L
    private var lastNotificationMs = 0L
    private var finishing = false
    private fun current(t: Long) = !destroyed && generation.get() == t
    private val complete = Runnable {
        if (current(token)) shutdown(token, commandId, "도착했습니다. 모의 위치 제공을 중지했습니다.")
    }
    private val tick = object : Runnable {
        override fun run() {
            worker.removeCallbacks(this)
            val t = token
            val motion = engine ?: return
            if (!current(t) || finishing) return
            try {
                val now = SystemClock.elapsedRealtime()
                check(now - startedMs < MAX_SESSION_MS) { "최대 실행 시간인 6시간이 지났습니다." }
                checkPrerequisites()
                motion.advance(now)
                val position = motion.route.position(motion.traveled)
                val loc = Location(LocationManager.GPS_PROVIDER).apply {
                    latitude = position.point.latitude
                    longitude = position.point.longitude
                    accuracy = 5f // Explicit simulation parameter, NOT measured sensor accuracy.
                    speed = motion.effectiveMps.toFloat()
                    bearing = position.bearing
                    time = System.currentTimeMillis()
                    elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
                    // Unknown altitude/vertical, speed and bearing accuracy are deliberately omitted.
                }
                val report = checkNotNull(backend).send(loc)
                if (!current(t)) return
                if (report.errors.isNotEmpty()) Log.w("MockGps", report.errors.joinToString())
                val mode = when {
                    motion.finished -> "도착했습니다. 곧 위치 제공을 중지합니다."
                    motion.paused -> "일시정지 중입니다. 현재 좌표를 유지합니다."
                    motion.route.fixed -> "고정 좌표를 제공하고 있습니다."
                    motion.speedKmh == 0.0 -> "속도가 0 km/h이므로 현재 좌표를 유지합니다."
                    else -> "도로 경로를 따라 이동하고 있습니다."
                }
                val details = String.format(Locale.KOREA,
                    "\n좌표: %.6f, %.6f\n모의 이동 속도: %.1f km/h · 설정: %.1f km/h\n이동 거리: %.2f / %.2f km",
                    position.point.latitude, position.point.longitude, motion.effectiveMps * 3.6,
                    motion.speedKmh, motion.traveled / 1000, motion.route.totalMeters / 1000)
                val remaining = (motion.route.totalMeters - motion.traveled).coerceAtLeast(0.0)
                val eta = if (motion.effectiveMps > 0) String.format(Locale.KOREA,
                    "\n현재 속도 기준 남은 시간은 약 %.1f분입니다.", remaining / motion.effectiveMps / 60) else ""
                val warning = if (report.errors.isEmpty()) "" else "\n제한 동작: ${report.errors.joinToString()}"
                publish(t, SessionSnapshot(true, motion.paused,
                    mode + details + eta + "\n주입 성공: ${report.succeeded.joinToString()}" + warning, motion.speedKmh))
                if (now - lastNotificationMs >= 1000 || motion.finished) {
                    main.post {
                        if (current(t)) {
                            try { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification()) }
                            catch (e: Exception) { Log.w("MockGps", "Notification update failed", e) }
                        }
                    }
                    lastNotificationMs = now
                }
                if (motion.finished) { finishing = true; worker.postDelayed(complete, 1000) }
                else worker.postDelayed(this, 500)
            } catch (e: Exception) {
                Log.e("MockGps", "Location delivery failed", e)
                if (current(t)) shutdown(t, commandId, "위치 제공을 중지했습니다: ${errorText(e)}")
            }
        }
    }
    override fun onCreate() {
        super.onCreate()
        manager = getSystemService(LocationManager::class.java)
        thread.start()
        worker = Handler(thread.looper)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "모의 GPS 실행", NotificationManager.IMPORTANCE_LOW))
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            START -> {
                val t = generation.incrementAndGet()
                SessionState.snapshot = SessionSnapshot(message = "경로와 위치 제공 방식을 준비하고 있습니다.", preparing = true)
                try {
                    checkPrerequisites()
                    if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
                    else startForeground(NOTIFICATION_ID, notification())
                    worker.post { if (current(t)) startSession(Intent(intent), t, startId) }
                } catch (e: Exception) {
                    // A failed promotion must stop immediately, not wait behind worker IO/FLP tasks.
                    SessionState.snapshot = SessionSnapshot(message = "시작하지 못했습니다: ${errorText(e)}")
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelfResult(startId)
                }
            }
            STOP -> {
                val t = generation.incrementAndGet() // Invalidate in-flight load/delivery immediately.
                worker.post { if (current(t)) shutdown(t, startId, "사용자가 모의 위치 제공을 중지했습니다.") }
            }
            PAUSE, SPEED -> {
                val t = generation.get()
                worker.post {
                    if (current(t)) {
                        commandId = startId
                        val motion = engine
                        if (motion != null && !finishing) {
                            try {
                                if (intent.action == PAUSE) motion.setPaused(!motion.paused, SystemClock.elapsedRealtime())
                                else motion.changeSpeed(intent.getDoubleExtra("speed", motion.speedKmh), SystemClock.elapsedRealtime())
                                lastNotificationMs = 0
                                tick.run()
                            } catch (e: IllegalArgumentException) { Log.w("MockGps", "Invalid control", e) }
                        } else if (motion == null && !SessionState.snapshot.preparing) {
                            shutdown(t, startId, "실행 중인 세션이 없습니다.")
                        }
                    }
                }
            }
            else -> if (!SessionState.snapshot.active && !SessionState.snapshot.preparing) stopSelfResult(startId)
        }
        return START_NOT_STICKY
    }
    private fun checkPrerequisites() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            throw SecurityException("위치 권한이 필요합니다. 앱 화면을 열고 다시 시작하세요.")
        val enabled = if (Build.VERSION.SDK_INT >= 28) manager.isLocationEnabled else
            manager.isProviderEnabled(LocationManager.GPS_PROVIDER) || manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        check(enabled) { "휴대폰의 위치 기능을 켜세요." }
        val selected = getSystemService(AppOpsManager::class.java).checkOpNoThrow(
            "android:mock_location", Process.myUid(), packageName)
        if (selected != AppOpsManager.MODE_ALLOWED) throw SecurityException("개발자 옵션에서 ‘테스트 GPS’를 모의 위치 앱으로 지정하세요.")
    }
    private fun startSession(intent: Intent, t: Long, startId: Int) {
        try {
            val errors = cleanup()
            check(errors.isEmpty()) { "이전 세션 정리가 완료되지 않았습니다. ${errors.joinToString()}" }
            if (!current(t)) return
            token = t
            commandId = startId
            val routeName = intent.getStringExtra("route")
            val route = if (routeName != null) RouteRepository.loadAndDelete(this, routeName)
                else RouteTrack(listOf(GeoPoint(intent.getDoubleExtra("lat", Double.NaN), intent.getDoubleExtra("lon", Double.NaN))))
            val speed = MotionEngine.checkedSpeed(intent.getDoubleExtra("speed", 30.0))
            if (!current(t)) return
            checkPrerequisites()
            val selected = intent.getStringExtra("backend") ?: "platform"
            require(selected == "platform" || selected == "google") { "지원하지 않는 위치 제공 방식입니다." }
            backend = if (selected == "google") GoogleFusedBackend(applicationContext) else PlatformBackend(manager)
            backend!!.open()
            if (!current(t)) { cleanup(); return }
            startedMs = SystemClock.elapsedRealtime()
            engine = MotionEngine(route, speed, startedMs)
            wakeLock = getSystemService(PowerManager::class.java).newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK, "MockGpsRoute:movement").apply {
                setReferenceCounted(false)
                acquire(MAX_SESSION_MS + 10000L)
            }
            tick.run()
        } catch (e: Exception) {
            Log.e("MockGps", "Session start failed", e)
            if (current(t)) shutdown(t, startId, "시작하지 못했습니다: ${errorText(e)}") else cleanup()
        }
    }
    private fun cleanup(): List<String> {
        worker.removeCallbacks(tick)
        worker.removeCallbacks(complete)
        engine = null
        finishing = false
        lastNotificationMs = 0
        val errors = try { backend?.close().orEmpty() } catch (e: Exception) { listOf("정리 실패: ${e.message}") }
        if (errors.isEmpty()) backend = null // Keep failed ownership for an onDestroy retry.
        else Log.e("MockGps", errors.joinToString())
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        return errors
    }
    private fun publish(t: Long, state: SessionSnapshot) {
        main.post { if (current(t)) SessionState.snapshot = state }
    }
    private fun shutdown(t: Long, startId: Int, message: String) {
        val errors = cleanup()
        val detail = if (errors.isEmpty()) "" else "\n${errors.joinToString()}\n모의 위치 앱 지정과 위치 설정을 확인하고, 복구되지 않으면 기기를 재시작하세요."
        main.post {
            if (current(t)) {
                SessionState.snapshot = SessionSnapshot(message = message + detail)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelfResult(startId)
            }
        }
    }
    override fun onDestroy() {
        destroyed = true
        generation.incrementAndGet()
        if (SessionState.snapshot.active || SessionState.snapshot.preparing)
            SessionState.snapshot = SessionSnapshot(message = "서비스가 종료되었습니다. 위치 제공 방식을 정리하고 있습니다.")
        val terminalState = SessionState.snapshot
        worker.post {
            val errors = cleanup()
            if (errors.isNotEmpty()) {
                Log.e("MockGps", "최종 정리 실패: ${errors.joinToString()}")
                main.post {
                    if (SessionState.snapshot === terminalState) SessionState.snapshot = SessionSnapshot(
                        message = terminalState.message + "\n정리 실패: ${errors.joinToString()}\n위치 설정을 확인하고, 복구되지 않으면 기기를 재시작하세요.")
                }
            }
            thread.quitSafely()
        }
        super.onDestroy()
    }
    private fun errorText(e: Exception): String {
        var cause: Throwable = e
        while (cause.cause != null && cause.cause !== cause) cause = cause.cause!!
        return when {
            e is SecurityException || cause is SecurityException -> "권한/모의 위치 설정 오류입니다. ${cause.message}"
            Build.VERSION.SDK_INT >= 31 && e is ForegroundServiceStartNotAllowedException -> "백그라운드 시작이 제한되었습니다. 앱 화면에서 다시 시작하세요."
            else -> cause.message ?: cause.javaClass.simpleName
        }
    }
    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        fun command(action: String, request: Int) = PendingIntent.getService(this, request,
            Intent(this, MockLocationService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("테스트 GPS · 모의 위치")
            .setContentText(SessionState.snapshot.message.lineSequence().first())
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(Notification.Action.Builder(null,
                if (SessionState.snapshot.paused) "재개" else "일시정지", command(PAUSE, 2)).build())
            .addAction(Notification.Action.Builder(null, "중지", command(STOP, 3)).build())
            .build()
    }

    companion object {
        const val START = "com.example.mockgps.START"
        const val STOP = "com.example.mockgps.STOP"
        const val PAUSE = "com.example.mockgps.PAUSE"
        const val SPEED = "com.example.mockgps.SPEED"
        private const val CHANNEL = "mock_location"
        private const val NOTIFICATION_ID = 2001
        private const val MAX_SESSION_MS = 6 * 60 * 60 * 1000L
    }
}
