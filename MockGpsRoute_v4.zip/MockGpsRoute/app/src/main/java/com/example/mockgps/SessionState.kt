package com.example.mockgps

data class SessionSnapshot(
    val active: Boolean = false,
    val paused: Boolean = false,
    val message: String = "중지 상태입니다.",
    val speedKmh: Double = 0.0,
    val preparing: Boolean = false
)
/** One application process; service never restarts itself after process death. */
object SessionState {
    @Volatile var snapshot = SessionSnapshot()
}
