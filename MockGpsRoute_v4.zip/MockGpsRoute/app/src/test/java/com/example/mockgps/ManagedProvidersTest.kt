package com.example.mockgps

import org.junit.Assert.*
import org.junit.Test

class ManagedProvidersTest {
    private class Fake : ProviderOps<Int> {
        val calls = mutableListOf<String>()
        val failures = mutableMapOf<String, RuntimeException>()
        private fun call(action: String, name: String) {
            val key = "$action:$name"
            calls.add(key)
            failures[key]?.let { throw it }
        }
        override fun add(name: String) = call("add", name)
        override fun enable(name: String) = call("enable", name)
        override fun disable(name: String) = call("disable", name)
        override fun remove(name: String) = call("remove", name)
        override fun send(name: String, value: Int) = call("send", name)
    }
    @Test fun successfulDeliveryIsReported() {
        val fake = Fake(); val p = ManagedProviders(fake)
        p.install(listOf("gps", "network"))
        assertEquals(listOf("gps", "network"), p.send(1).succeeded)
        assertTrue(p.send(1).errors.isEmpty())
    }
    @Test fun allDeliveryFailuresAreFatal() {
        val fake = Fake(); val p = ManagedProviders(fake)
        p.install(listOf("gps"))
        fake.failures["send:gps"] = IllegalArgumentException("broken")
        assertThrows(IllegalStateException::class.java) { p.send(1) }
    }
    @Test fun partialDeliveryProducesWarning() {
        val fake = Fake(); val p = ManagedProviders(fake)
        p.install(listOf("gps", "network"))
        fake.failures["send:network"] = IllegalArgumentException("broken")
        val report = p.send(1)
        assertEquals(listOf("gps"), report.succeeded)
        assertTrue(report.errors.single().contains("network"))
    }
    @Test fun permissionFailureIsNotHiddenByOtherSuccess() {
        val fake = Fake(); val p = ManagedProviders(fake)
        p.install(listOf("gps", "network"))
        fake.failures["send:network"] = SecurityException("revoked")
        assertThrows(SecurityException::class.java) { p.send(1) }
    }
    @Test fun enableFailureRollsBackOwnedProvider() {
        val fake = Fake(); val p = ManagedProviders(fake)
        fake.failures["enable:gps"] = IllegalArgumentException("enable failed")
        assertThrows(IllegalStateException::class.java) { p.install(listOf("gps")) }
        assertTrue(fake.calls.contains("remove:gps"))
        assertTrue(p.close().isEmpty())
    }
    @Test fun disableFailureStillAttemptsRemoval() {
        val fake = Fake(); val p = ManagedProviders(fake)
        p.install(listOf("gps"))
        fake.failures["disable:gps"] = IllegalArgumentException("disable failed")
        assertTrue(p.close().isEmpty())
        assertTrue(fake.calls.contains("remove:gps"))
    }
    @Test fun failedRemovalIsRetainedForRetry() {
        val fake = Fake(); val p = ManagedProviders(fake)
        p.install(listOf("gps"))
        fake.failures["remove:gps"] = SecurityException("revoked")
        assertEquals(1, p.close().size)
        fake.failures.clear()
        assertTrue(p.close().isEmpty())
        assertEquals(2, fake.calls.count { it == "remove:gps" })
    }
    @Test fun failedRollbackIsRetainedForCleanup() {
        val fake = Fake(); val p = ManagedProviders(fake)
        fake.failures["enable:gps"] = IllegalArgumentException("enable failed")
        fake.failures["remove:gps"] = SecurityException("revoked")
        assertThrows(IllegalStateException::class.java) { p.install(listOf("gps")) }
        fake.failures.clear()
        assertTrue(p.close().isEmpty())
        assertEquals(2, fake.calls.count { it == "remove:gps" })
    }
    @Test fun failedAddDoesNotRemoveAnUnownedProvider() {
        val fake = Fake(); val p = ManagedProviders(fake)
        fake.failures["add:gps"] = IllegalArgumentException("not added")
        assertThrows(IllegalStateException::class.java) { p.install(listOf("gps")) }
        p.close()
        assertFalse(fake.calls.contains("remove:gps"))
    }
    @Test fun successfulCleanupIsIdempotent() {
        val fake = Fake(); val p = ManagedProviders(fake)
        p.install(listOf("gps", "gps"))
        p.close(); p.close()
        assertEquals(1, fake.calls.count { it == "add:gps" })
        assertEquals(1, fake.calls.count { it == "remove:gps" })
    }
}
