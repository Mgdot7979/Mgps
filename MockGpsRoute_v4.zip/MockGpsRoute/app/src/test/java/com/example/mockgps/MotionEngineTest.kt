package com.example.mockgps

import org.junit.Assert.*
import org.junit.Test

class MotionEngineTest {
    private fun route() = RouteTrack(listOf(GeoPoint(0.0, 0.0), GeoPoint(0.0, 0.1)))
    @Test fun equatorialDistance() {
        assertEquals(11119.508, route().totalMeters, 0.01)
    }
    @Test fun speedControlsTraveledDistance() {
        val engine = MotionEngine(route(), 36.0, 0)
        engine.advance(10000)
        assertEquals(100.0, engine.traveled, 0.0001)
    }
    @Test fun speedChangeDoesNotRewriteThePast() {
        val engine = MotionEngine(route(), 36.0, 0)
        engine.changeSpeed(72.0, 10000)
        engine.advance(15000)
        assertEquals(200.0, engine.traveled, 0.0001)
    }
    @Test fun pauseResumeExcludesPausedTime() {
        val engine = MotionEngine(route(), 36.0, 0)
        engine.setPaused(true, 1000)
        engine.advance(9000)
        assertEquals(10.0, engine.traveled, 0.0001)
        assertEquals(0.0, engine.effectiveMps, 0.0)
        engine.setPaused(false, 10000)
        engine.advance(11000)
        assertEquals(20.0, engine.traveled, 0.0001)
    }
    @Test fun zeroSpeedHoldsPosition() {
        val engine = MotionEngine(route(), 0.0, 0)
        engine.advance(10000)
        assertEquals(0.0, engine.traveled, 0.0)
        assertFalse(engine.finished)
    }
    @Test fun arrivalClampsToDestination() {
        val engine = MotionEngine(route(), 200.0, 0)
        engine.advance(99999999)
        assertEquals(engine.route.totalMeters, engine.traveled, 0.0)
        assertEquals(engine.route.points.last(), engine.route.position(engine.traveled).point)
        assertTrue(engine.finished)
        assertEquals(0.0, engine.effectiveMps, 0.0)
    }
    @Test fun fixedPointNeverArrives() {
        val engine = MotionEngine(RouteTrack(listOf(GeoPoint(37.0, 127.0))), 100.0, 0)
        engine.advance(10000)
        assertFalse(engine.finished)
        assertEquals(0.0, engine.effectiveMps, 0.0)
    }
    @Test fun duplicatePointsAreRemoved() {
        val point = GeoPoint(0.0, 0.0)
        val r = RouteTrack(listOf(point, point, GeoPoint(0.0, 0.1)))
        assertEquals(2, r.points.size)
        assertEquals(0.05, r.position(r.totalMeters / 2).point.longitude, 1e-8)
    }
    @Test fun followsCornerRatherThanEndpointShortcut() {
        val corner = GeoPoint(0.0, 0.01)
        val r = RouteTrack(listOf(GeoPoint(0.0, 0.0), corner, GeoPoint(0.01, 0.01)))
        val p = r.position(r.cumulative[1]).point
        assertEquals(corner.latitude, p.latitude, 1e-8)
        assertEquals(corner.longitude, p.longitude, 1e-8)
        assertEquals(0f, r.position(r.cumulative[1]).bearing, 0.01f)
    }
    @Test fun interpolatesAcrossDateLine() {
        val midpoint = GeoMath.interpolate(GeoPoint(0.0, 179.9), GeoPoint(0.0, -179.9), 0.5)
        assertEquals(180.0, kotlin.math.abs(midpoint.longitude), 1e-6)
    }
    @Test(expected = IllegalArgumentException::class)
    fun rejectsNonfiniteCoordinate() { GeoPoint(Double.NaN, 0.0) }
    @Test(expected = IllegalArgumentException::class)
    fun rejectsOutOfRangeCoordinate() { GeoPoint(91.0, 0.0) }
    @Test(expected = IllegalArgumentException::class)
    fun rejectsNegativeSpeed() { MotionEngine(route(), -1.0, 0) }
    @Test(expected = IllegalArgumentException::class)
    fun rejectsNonfiniteSpeed() { MotionEngine(route(), Double.NaN, 0) }
    @Test(expected = IllegalArgumentException::class)
    fun rejectsDecreasingClock() { MotionEngine(route(), 30.0, 100).advance(99) }
}
